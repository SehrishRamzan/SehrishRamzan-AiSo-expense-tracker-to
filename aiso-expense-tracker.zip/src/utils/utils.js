export const url =
  process.env.NODE_ENV === "production" ? "" : "http://localhost:6060";
