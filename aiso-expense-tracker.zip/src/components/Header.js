import React from 'react'

export const Header = () => {
    return (
        <h2>
            AiSo Expense Tracker
        </h2>
    )
}
