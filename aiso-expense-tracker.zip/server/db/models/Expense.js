let mongoose = require("mongoose");

let ExpenseSchema = mongoose.Schema({
  description: String,
  amount: Number,
});
let Expenses = mongoose.model("Expense", ExpenseSchema);
module.exports = Expenses;
