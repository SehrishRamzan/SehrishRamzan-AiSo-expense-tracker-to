module.exports = {
  secret: "maano",
};
