let express = require("express");
var cors = require("cors");
let myApp = express();
myApp.use(cors());
let path = require("path");

let BodyParser = require("body-parser");
myApp.use(BodyParser.json());
let config = require("./config");
let jwt = require("jsonwebtoken");
const jwt_decode = require("jwt-decode");

let mongoose = require("mongoose");
let SiteUsers = require(".//db/models/users");
let Transactions = require(".//db/models/Expense");
mongoose.connect(
  "mongodb+srv://Sehrish:tcf381509@cluster0.r96s4.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
  (err, connection) => {
    console.log(err || connection);
  }
);

myApp.post("/checksession", async function (req, res) {
  var decoded = jwt_decode(req.body.token);
  if (decoded.id) {
    SiteUsers.findOne({ _id: decoded.id }, function (err, docs) {
      res.send(docs);
    });
  }
});

myApp.post("/signup", async function (req, res) {
  let user1 = await SiteUsers.findOne({
    email: req.body.email,
  });
  if (user1) {
    res.json({
      msg: "Email Already in Use",
    });
  } else {
    let user = new SiteUsers();
    // eslint-disable-next-line no-unused-expressions
    (user.name = req.body.name),
      (user.email = req.body.email),
      (user.password = req.body.password),
      (user.contact = req.body.contact),
      await user.save();

    res.json({
      msg: "Signed Up...!",
    });
  }
});
myApp.post("/login", async function (req, res) {
  let user = await SiteUsers.findOne({
    email: req.body.email,
    password: req.body.password,
  });

  if (user) {
    let userToken = { id: user._id };
    jwt.sign(
      userToken,
      config.secret,
      {
        expiresIn: "2d",
      },
      (err, token) => {
        res.json({
          token,
          success: true,
          msg: "User Found",
          _id: user._id,
          name: user.name,
          password: user.password,
          email: user.email,
        });
      }
    );
  } else {
    res.json({
      msg: "User Not Found",
    });
  }
});
myApp.post("/addExpense", async (req, res) => {
  console.log(req.body);
  let expense = new Transactions();
  expense.description = req.body.description;
  expense.amount = req.body.transactionAmount;
  await expense.save();
  res.json({
    msg: "success",
  });
});

myApp.get("/getRecord", async (req, res) => {
  const data = await Transactions.find();
  console.log(data);
  res.send({
    data: data,
  });

  // console.log(data[0]._doc);
});

myApp.use(express.static("./server/build"));
myApp.use(express.static("./build"));

myApp.use("*", (req, res) => {
  res.sendFile(path.join(__dirname, "./build", "index.html"));
});

myApp.listen(process.env.PORT || 6060, function () {
  console.log("Server in Working State");
});
